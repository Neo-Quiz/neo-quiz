# Introduction à l'écosystème

```quiz-blocks
[{ title: 'CM1 Écosystème', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```
