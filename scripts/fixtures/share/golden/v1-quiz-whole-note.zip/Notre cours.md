---
tags: [cours]
---
# Notre cours

Un texte avant le quiz.

![](img/figure.PNG)

```quiz-blocks
[{ title: 'Notre cours', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```

Et après.
