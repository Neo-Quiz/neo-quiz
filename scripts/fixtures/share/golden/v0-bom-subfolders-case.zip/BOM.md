﻿# Avec BOM

![](img/Photo.JPG)

```quiz-blocks
[{ title: 'Bom', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```
