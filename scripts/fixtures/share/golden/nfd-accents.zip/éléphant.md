![[éléphant.png]]
```quiz-blocks
[{ title: 'Éléphant', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```
