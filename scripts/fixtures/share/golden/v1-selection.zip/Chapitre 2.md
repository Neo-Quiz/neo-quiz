# Chapitre 2

```quiz-blocks
[{ title: 'Chapitre 2', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```
