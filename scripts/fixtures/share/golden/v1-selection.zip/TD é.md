# TD évalué

Voir ![[schéma.png]]

```quiz-blocks
[{ title: 'TD', prompt: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon'], correctIndex: 0 }]
```
